import React, {Component} from 'react';

class Business extends Component {
    render() {
        return (
            <div>
                <h1>Business</h1>
            </div>
        );
    }
}

export default Business;