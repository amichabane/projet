import React, {Component} from 'react';

class Entertainement extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default Entertainement;